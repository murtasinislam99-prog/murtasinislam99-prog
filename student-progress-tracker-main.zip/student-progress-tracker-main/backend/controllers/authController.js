// controllers/authController.js
const jwt = require('jsonwebtoken');
const User = require('../models/User');

const JWT_SECRET = process.env.JWT_SECRET;
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d'; // e.g. '7d' or '1h'

// Simple in-memory blacklist (dev only)
const tokenBlacklist = new Set();

exports.register = async (req, res) => {
  try {
    console.log('Registration request received:', { name: req.body.name, email: req.body.email, role: req.body.role });
    const { name, email, password, role } = req.body;

    if (!name || !email || !password) {
      console.log('Validation failed: Missing required fields');
      return res.status(400).json({ message: 'Name, email and password are required' });
    }

    // Password validation rules
    const passwordErrors = [];
    if (password.length < 8) {
      passwordErrors.push('At least 8 characters');
    }
    if (!/[A-Z]/.test(password)) {
      passwordErrors.push('One uppercase letter');
    }
    if (!/[a-z]/.test(password)) {
      passwordErrors.push('One lowercase letter');
    }
    if (!/[0-9]/.test(password)) {
      passwordErrors.push('One number');
    }
    if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
      passwordErrors.push('One special character');
    }
    
    if (passwordErrors.length > 0) {
      return res.status(400).json({ 
        message: `Password must contain: ${passwordErrors.join(', ')}` 
      });
    }

    const existing = await User.findOne({ email });
    if (existing) {
      return res.status(400).json({ message: 'Email already registered' });
    }

    const user = new User({ name, email, password, role: role || 'student' });
    console.log('Saving user to database...');
    await user.save();
    console.log('User saved successfully:', user._id);

    // Ensure JWT secret is configured
    if (!JWT_SECRET) {
      console.error('JWT_SECRET is not set in environment');
      return res.status(500).json({ message: 'Server misconfiguration: JWT_SECRET missing' });
    }

    // Create token
    const token = jwt.sign({ id: user._id, role: user.role }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
    console.log('Token created successfully');

    const response = {
      message: 'User registered successfully',
      user: { 
        id: user._id.toString(), 
        _id: user._id.toString(),
        name: user.name, 
        email: user.email, 
        role: user.role 
      },
      token
    };
    
    console.log('Sending success response');
    return res.status(201).json(response);
  } catch (error) {
    console.error('Register error details:', error);
    console.error('Error message:', error.message);
    console.error('Error stack:', error.stack);
    
    // More specific error messages
    if (error.code === 11000) {
      return res.status(400).json({ message: 'Email already registered' });
    }
    if (error.name === 'ValidationError') {
      return res.status(400).json({ message: error.message });
    }
    
    return res.status(500).json({ 
      message: 'Server error registering user',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password)
      return res.status(400).json({ message: 'Email and password are required' });

    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ message: 'Invalid credentials' });

    const isMatch = await user.comparePassword(password);
    if (!isMatch) return res.status(400).json({ message: 'Invalid credentials' });

    if (!JWT_SECRET) {
      console.error('JWT_SECRET is not set in environment');
      return res.status(500).json({ message: 'Server misconfiguration: JWT_SECRET missing' });
    }

    const token = jwt.sign({ id: user._id, role: user.role }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });

    return res.status(200).json({
      message: 'Login successful',
      user: { id: user._id, name: user.name, email: user.email, role: user.role },
      token,
    });
  } catch (error) {
    console.error('Login error:', error);
    return res.status(500).json({ message: 'Server error logging in' });
  }
};

exports.logout = async (req, res) => {
  try {
    // Accept token from header or body
    const authHeader = req.headers.authorization || '';
    const token = authHeader.startsWith('Bearer ') ? authHeader.split(' ')[1] : req.body.token;

    if (!token) return res.status(400).json({ message: 'No token provided' });

    // Add token to blacklist
    tokenBlacklist.add(token);
    return res.status(200).json({ message: 'Logged out successfully' });
  } catch (error) {
    console.error('Logout error:', error);
    return res.status(500).json({ message: 'Server error during logout' });
  }
};

// Helper to access the blacklist from middleware
exports.__tokenBlacklist = tokenBlacklist;

exports.getMe = async (req, res) => {
  try {
    // auth middleware attaches req.userId
    const user = await User.findById(req.userId).select('-password');
    if (!user) return res.status(404).json({ message: 'User not found' });
    return res.status(200).json({ user });
  } catch (error) {
    console.error('getMe error:', error);
    return res.status(500).json({ message: 'Server error' });
  }
};
